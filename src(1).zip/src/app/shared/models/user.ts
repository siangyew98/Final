export class User {
    photoURL: string;
    constructor(public companyname?: string, public email?: string, public password?: string)
    {

    }
}